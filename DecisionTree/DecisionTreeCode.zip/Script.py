'''
    @author - Angel Dhungana
    Script file that runs the train/test Car and Train/Test Bank
'''
import TrainAndTestBank
import TrainAndTestCar


def main():
    TrainAndTestCar.main()
    TrainAndTestBank.main()


if __name__ == "__main__":
    main()